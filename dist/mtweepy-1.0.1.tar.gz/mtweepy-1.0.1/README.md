# Makes _something_ easy again!
[![License: MIT](https://img.shields.io/github/license/{user_name_}/{repo_or_package_name_})](https://opensource.org/licenses/MIT)
[![stars](https://img.shields.io/github/stars/{user_name_}/{repo_or_package_name_})]()
[![Github All Releases](https://img.shields.io/github/downloads/huggingface/transformers/total.svg)]()
[![PyPI](https://img.shields.io/pypi/v/{repo_or_package_name_})](https://pypi.org/project/{repo_or_package_name_}/)
[![python](https://img.shields.io/github/languages/top/{user_name_}/{repo_or_package_name_})]()

[![Build Status](https://scrutinizer-ci.com/g/{user_name_}/{repo_or_package_name_}/badges/build.png?b=main)](https://scrutinizer-ci.com/g/{user_name_}/{repo_or_package_name_}/build-status/main)
[![Scrutinizer Code Quality](https://scrutinizer-ci.com/g/{user_name_}/package_creator/badges/quality-score.png?b=main)](https://scrutinizer-ci.com/g/{user_name_}/package_creator/?branch=main)
[![Release date](https://img.shields.io/github/release-date/{user_name_}/{repo_or_package_name_})]()
[![Latest Stable Version](https://img.shields.io/github/v/release/{user_name_}/{repo_or_package_name_})]()

[![tweet](https://img.shields.io/twitter/url?style=social&url=https%3A%2F%2Fgithub.com%2F{user_name_}%2F{repo_or_package_name_})]()

### Support me


[![Buy Me A Coffee](https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png)](https://www.buymeacoffee.com/{user_name_})


Some appreciatory description
- [x] Lightweight
- [x] Easiest to use 

## Install from PyPi
```
pip3 install {repo_or_package_name_}
```

## Or Install from main branch
```
pip3 install git+https://github.com/{user_name_}/{repo_or_package_name_}.git
```

# One interactive command with easy-to-follow prompts to create/upload/update them all!
```
cmpp
```

You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.

